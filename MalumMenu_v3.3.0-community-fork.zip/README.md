# MalumMenu 3.3.0 Community Build

> ⚠️ UNOFFICIAL COMMUNITY BUILD — USE AT YOUR OWN RISK

This is an unofficial community build of MalumMenu 3.3.0.

Built from source and tested with:

- Among Us: 2026.8.18 (v18)
- Platform: Epic Games
- BepInEx: compatible installation required

## Changes

- Added Role Swap (host-only), based on terminator2481's PR:
  https://github.com/scp222thj/MalumMenu/pull/661
- Added The Judge to the "Set Fake Role" selection menu.

## Installation

Extract the ZIP file, copy MalumMenu.dll you obtain from it. Paste it in the plugins subfolder of BepInEx in your game's directory. 
E.g. C:\ProgramFiles\EpicGames\AmongUs\BepInEx\Plugins 
Make sure no other plugin interferes with it.

## Known Issue — The Judge Overrule & Set Fake Role interaction

The Judge functionality is currently experimental and **should not be used in public games**.

When The Judge's Overrule ability is used in combination with Set Fake Role, Among Us can disconnect the client with:

`Server > Client DC because Hacking: null`

The affected client log also records an increase in ban points, I haven't figured out whether this is directly caused by me not bypassing the anticheat right or the way Among Us handles meetings now is much more secure.

I have not identified the underlying cause yet. This build is therefore provided primarily for development/testing purposes.

## Important

This is NOT an official MalumMenu release.

I am not affiliated with or representing the MalumMenu developers, and I am not profiting from this build.

Please don't use the experimental functionality in public games until the issue is understood and fixed.

If you can help diagnose the issue, please open an issue or contact me through the project's community channels and/or ping me in the Discord.

## Credits

- terminator2481 — Role Swap PR
- scp222thj — MalumMenu lead developer
- All MalumMenu contributors I haven't explicitly named
- Haldaw - put it all togheter